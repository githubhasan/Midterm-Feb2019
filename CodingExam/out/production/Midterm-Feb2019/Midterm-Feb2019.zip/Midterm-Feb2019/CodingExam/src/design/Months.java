/*package design;

public enum Months {
    January, February, March, April, May, June, July, August, September, October, November, December
}*/

package design;

public enum Months {
    January, February, March, April, May, June, July, August, September, October, November, December
}
