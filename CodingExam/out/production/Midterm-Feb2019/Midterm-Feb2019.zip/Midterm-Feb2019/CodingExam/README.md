#####JAVA Midterm

This is the Core Java Midterm.